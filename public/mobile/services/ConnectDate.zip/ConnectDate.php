<?php

class ConnectDate {

    public $ip, $id, $password, $database;

    public function __construct() {
        $this -> ip = "localhost";
        $this -> id = "root";
        $this -> password = "123456";
        $this -> database = "minaodo";
    }

}

?>